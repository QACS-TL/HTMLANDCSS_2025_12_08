function validateForm() {
  let x = document.forms["myForm"]["UsrName"].value;
  if (x.trim() == "") {
    alert("Name must be filled out");
    return false;
  }
}


function validateTwoFieldForm() {
  let txtName = document.forms["myForm"]["UsrName"].value;
  if (txtName.trim() == "") {
    alert("Name must be filled out");
    return false;
  }
  let txtAddress = document.forms["myForm"]["UsrAddr"].value;
  if (txtAddress.trim() == "") {
    alert("Address must be filled out");
    return false;
  }
}


function validateDrinksForm() {
  let withmilk = "";
  let withsugar = "";
  
  let drink = document.forms["myForm"]["RadioDrink"].value;
  if (drink == "") {
    alert("A drink must be chosen");
    return false;
  }
  let milk = document.forms["myForm"]["CheckMilk"].checked;
  if (milk == false) {
    withmilk = "no ";
  }
  let sugar = document.forms["myForm"]["CheckSugar"].checked;
  if (sugar == false) {
    withsugar = "no ";
  }
  if (drink == "Soup" && (milk == true|| sugar == true)){
      alert("You can't add milk or sugar to soup!");
      return false;
  }
  if (drink == "Soup"){
      alert("A drink of " + drink + " has been selected");
      return true;
  }
  alert("A drink of " + drink + " with " + withmilk + "milk and with " + withsugar + " sugar has been selected");
}

function validateFoodForm() {
  let foodName = "";
  let portionsize = "";
  
  let foodtype = document.forms["myForm"]["Drop1"].value;
  if (foodtype == "") {
    alert("A food must be chosen");
    return false;
  }

  let size = document.forms["myForm"]["Drop2"].value;
  if (size == "" || size < "0" || size > "3") {
    alert("A size must be chosen");
    return false;
  }

  if (size == "0") {
    portionsize = "small";
  }
  else if(size == "1") {
    portionsize = "medium";
  }
  else
  {
    portionsize = "large";
  }
  
  alert("A " + portionsize + " portion of " + foodtype + " has been selected");
}



function validateTwoFieldWithEmailAddressForm() {
  let txtName = document.forms["myForm"]["UsrName"].value;
  if (txtName.trim() == "") {
    alert("Name must be filled out");
    return false;
  }
  let txtemail = document.forms["myForm"]["UsrEmail"].value;
  if (txtemail.trim() == "") {
    alert("Email Address must be filled out");
    return false;
  }
}



function validateUrlAddressForm() {
  let txturl = document.forms["myForm"]["UsrUrl"].value;
  if (txturl.trim() == "") {
    alert("Url must be filled out");
    return false;
  }
}



function validateNumberForm() {
  let number = document.forms["myForm"]["UsrNumber"].value;
  if (number.trim() == "") {
    alert("A number is required");
    return false;
  }
}


function validateRangeForm() {
  let range = document.forms["myForm"]["UsrRange"].value;
  if (range.trim() == "") {
    alert("A range value is required");
    return false;
  }
}


function validateDateForm() {
  let txtsearchdetails = document.forms["myForm"]["usrsearch"].value;
  if (txtsearchdetails.trim() == "") {
    alert("Some search data is required");
    return false;
  }
}


function validateColourForm() {
  let colour = document.forms["myForm"]["usrcolour"].value;
  if (colour == "") {
    alert("Some colour info is required");
    return false;
  }
}


function validatePatternForm() {
  let cardnumber = document.forms["myForm"]["usrcardnumber"].value;
  if (cardnumber == "") {
    alert("card number is needed and must lie between 13 and 16 digits");
    return false;
  }
}



function validateDatalistForm() {
  let browser = document.forms["myForm"]["browser"].value;
  if (browser == "") {
    alert("A browser must be selected");
    return false;
  }
}