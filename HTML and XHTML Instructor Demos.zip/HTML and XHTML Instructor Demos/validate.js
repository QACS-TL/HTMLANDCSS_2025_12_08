function validateForm() {
  let x = document.forms["myForm"]["UsrName"].value;
  if (x == "") {
    alert("js folder Name must be filled out");
    return false;
  }
}


function validateTwoFieldForm() {
  let txtName = document.forms["myForm"]["UsrName"].value;
  if (txtName == "") {
    alert("js folder Name must be filled out");
    return false;
  }
  let txtAddress = document.forms["myForm"]["UsrAddr"].value;
  if (txtAddress == "") {
    alert("js folder Address must be filled out");
    return false;
  }
}


function validateDrinksForm() {
  alert("Validating!");
  let drink = document.forms["myForm"]["RadioDrink"].value;
  if (drink == "") {
    alert("A drink must be chosen");
    return false;
  }
  let milk = document.forms["myForm"]["CheckMilk"].value;
  if (milk == "") {
    milk = "no";
  }
    let sugar = document.forms["myForm"]["CheckMilk"].value;
  if (sugar == "") {
    sugar = "no";
  }
  if (drink == "Soup" && (milk == "Yes" || sugar == "Yes")){
      alert("You can't add milk or sugar to soup!");
      return false;
  }
  alert("A drink of " + drink + " with " + milk + " milk and " + sugar + " sugar has been selected");
}