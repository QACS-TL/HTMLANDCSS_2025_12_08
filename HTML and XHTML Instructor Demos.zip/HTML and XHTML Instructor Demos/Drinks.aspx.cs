﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Demo
{
    public class Drinks : System.Web.UI.Page
    {
        protected void  Page_Load(object sender, EventArgs e)
        {
           if ((Request.Form["CheckMilk"] != null) && (Request.Form["CheckMilk"].ToString() == "Yes"))
            {
                lblMilk.Text = " white ";
            }
            else
            {
                lblMilk.Text = " black ";
            }


            if ((Request.Form["CheckSugar"] != null) && (Request.Form["CheckSugar"].ToString() == "Yes"))
            {
                lblSugar.Text = " with sugar";
            }
            else
            {
                lblSugar.Text = "without sugar";
            }

            if (Request.Form["RadioDrink"] != null)
            {
                lblDrink.Text = Request.Form["RadioDrink"].ToString();
		if (Request.Form["RadioDrink"].ToString() == "Soup")
		{
			lblMilk.Text = "";
			lblSugar.Text = "";
		}
            }
            else
            {
                lblDrink.Text = "Drink not selected";
            }

 
        }

        protected HtmlHead Head1;
        protected HtmlForm form1;
        protected Label lblDrink;
        protected Label lblMilk;
        protected Label lblSugar;

    }
}