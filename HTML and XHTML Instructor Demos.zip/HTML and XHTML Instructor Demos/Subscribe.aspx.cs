﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Demo
{
    public class Subscribe : System.Web.UI.Page
    {
        protected void  Page_Load(object sender, EventArgs e)
        {
            if (Request.Form["UsrName"] != null)
            {
                lblName.Text = Request.Form["UsrName"].ToString();
            }
            else
            {
                lblName.Text = "Anon";
            }
        }

        protected HtmlHead Head1;
        protected HtmlForm form1;
        protected Label lblName;

    }
}